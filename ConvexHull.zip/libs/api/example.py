import wrapper

print(wrapper.findOrthogonalConvexHull('100000.csv', 'temp.csv'))
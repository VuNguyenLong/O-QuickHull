#include <iostream>
#include "convex_ohq.h"

int main(int argc, char** argv)
{
    findOrthogonalConvexHull(argv[1], argv[2]);
}